# QNX Safety Supervisor (Mini)

A small, hackathon-sized version of the **Autonomous Vehicle Safety Supervisor**
problem, written in C for **QNX Neutrino** on a **Raspberry Pi 4** robot car.

> **One-line idea:** *Navigation proposes, Safety decides, Motors obey.*
> Navigation can ask for anything it wants, but nothing reaches the motors
> unless the Safety Supervisor (highest priority task) approves it - and if
> the sensors or any task look unhealthy, the car stops.

---

## 1. Problem we are solving

An autonomous vehicle has a "driver" (navigation) that is not always right.
We need a separate, higher-priority component that:

1. **Overrides unsafe commands** from navigation within a **fixed deadline**.
2. **Monitors the sensors** and stops the vehicle if they cannot be trusted.
3. **Monitors the tasks themselves** (heartbeat watchdog) and recovers / fails safe.
4. Does all of this with **real-time guarantees** (priorities, bounded blocking).

This mini project does exactly those four things and nothing more. It runs on
**real hardware only** (no simulation).

---

## 2. Project layout

```
qnx_mini_project/
├── README.md
├── Makefile.standalone            optional command-line build (the IDE uses its own Makefile)
└── src/                           (the IDE compiles every .c under src/ automatically)
    ├── qnx_mini_project.c         main(): start-up order, Ctrl+C shutdown
    ├── common/                    things every module shares
    │   ├── config.h               ALL tunable numbers (thresholds, priorities, pins)
    │   ├── messages.h             message structs, pulse codes, enums (the "protocol")
    │   └── log.c/h                thread-safe logger
    ├── system/                    real-time plumbing
    │   ├── ticker.c/h             periodic kernel timer -> pulse
    │   ├── watchdog.c/h           heartbeat monitor + forced stop (our "recovery")
    │   └── rt_util.c/h            clock, SCHED_FIFO threads, send-with-timeout
    ├── sensors/                   everything about reading sensors
    │   ├── sensor_monitor.c/h     task: reads the sensors, sends clean data to Safety
    │   ├── sensor_health.c/h      per-sensor filtering + OK / FAULT status
    │   └── median_filter.c/h      the 5-sample median filter itself
    ├── safety/
    │   └── safety_supervisor.c/h  the decision maker + deadline check
    ├── navigation/
    │   └── navigation.c/h         proposes motion; pivots if blocked
    ├── motor/
    │   └── motor_controller.c/h   executes approved commands, dead-man timer
    ├── display/
    │   └── display_task.c/h       OLED task: U1 / U2 + big status text
    └── drivers/                   hardware drivers (talk to the chips)
        ├── hc_sr04.c/h            ultrasonic distance sensor
        ├── drv8833.c/h            motor driver
        └── oled_sh1106.c/h        OLED display driver (I2C)
```

Rule of thumb: **`src/drivers/` = talks to hardware, the other folders = our logic.**
Every function in every file has a comment above it explaining what it does and why.

---

## 3. Architecture

Everything runs as **threads in one QNX process**. They talk only through
**QNX message passing** (no shared variables between tasks).

```
   HC-SR04 x2 (src/drivers/hc_sr04)
        |
        v
 +-----------------------------+
 |  Sensor Monitor   prio 10   |   raw reading -> sensor_health -> median filter
 |  (sensors/)                 |   -> filtered cm + OK/FAULT status
 +--------------+--------------+
                | MsgSend (clean distances + status)
                v
 +----------------+  MsgSend   +------------------------+  MsgSend   +--------------------+
 |  Navigation    | ---------> |   Safety Supervisor    | ---------> |  Motor Controller  | --> drv8833 --> wheels
 |   prio 20      | <--------- |       prio 30          | <--------- |      prio 25       |
 +----------------+  MsgReply  +-----------+------------+  MsgReply  +--------------------+
   (wants to go                 (the ONLY  | pulse (never waits)       (just executes,
    forward)                    decision   v                            + dead-man timer)
                                maker)  +--------------------+
                                        |  Display  prio 5   | --> src/drivers/oled_sh1106 --> OLED
                                        +--------------------+

 every task ----- heartbeat PULSE -----> +--------------------+
                                         |  Watchdog  prio 15 |  -> if a heartbeat is missing: log + force STOP
                                         +--------------------+
```

### One control tick (75 ms)

1. A kernel **timer pulse** wakes Navigation.
2. Navigation `MsgSend`s `{FORWARD, 60%}` to Safety and **blocks**.
3. Safety looks at the latest sensor data and decides the approved speed.
4. Safety `MsgSend`s the approved command to the Motor Controller.
5. Safety checks it finished within the **deadline** (75 ms), sends a
   non-blocking **pulse** to the Display task, then `MsgReply`s
   `{state, approved_speed}` to Navigation.
6. Navigation sends a heartbeat pulse to the Watchdog and waits for the next tick.

### Safety rules (`safety/safety_supervisor.c`)

| Situation | State | Motor speed |
|---|---|---|
| A sensor is not `OK` (still waiting / faulty) or data older than 400 ms | `FAULT` | 0 (stop) |
| Nearest obstacle <= 15 cm | `EMERGENCY` | 0 (stop) |
| 15 cm < obstacle <= 60 cm | `WARNING` | scaled down linearly (min 20 %) |
| Obstacle > 60 cm | `SAFE` | as requested |
| Decision + motor ack took longer than the deadline | fail-safe | stop |

Turning in place (pivot) is allowed in an emergency, capped at 40 %, because that
is how the car escapes a blocked path.

---

## 4. The median filter - where and how it is used

**Problem:** cheap HC-SR04 modules give an occasional dropout (`-1`) or a wild
spike (e.g. 380 cm between 100 cm readings). If Safety reacted to every raw
reading, the car would randomly stop or declare a sensor fault.

**Where it lives (the call chain):**

```
sensor_monitor.c   every 100 ms:  raw = read_distance(sensor i)
      |
      v
sensor_health.c    sensor_health_update(&health[i], raw)     <- one sensor_health_t per sensor
      |   uses
      v
median_filter.c    mf_add() / mf_ready() / mf_median()       <- the actual median maths
      |
      v
sensor_monitor.c   puts  filtered distance + status  into the message for Safety
```

So the filter is used **inside the Sensor Monitor task**, and Safety only ever receives
clean data.

**How it works (`sensor_health.c`):**

1. A **good** reading goes into a window of the last 5 good readings. The distance
   given to Safety is the **median** of that window - a single spike is outvoted.
   Example: `100, 100, 380, 100, 100` -> median `100` (an average would give 156).
2. A **bad** reading (`-1`) is ignored; the previous median stays in use.
3. Only **10 bad readings in a row** (about 1 s) make a sensor `FAULT`.
4. A faulty sensor must deliver **3 good readings in a row** to be trusted again,
   so it cannot flip between fault and recovered.
5. A sensor is `WAITING` (not trusted) until it has 3 good readings after start-up.

The price: a median reacts about 2 readings (~200 ms) late to a *real* change, small
compared to the 60 cm / 15 cm thresholds. Tune `MEDIAN_WINDOW`, `MEDIAN_MIN_SAMPLES`
and `SENSOR_FAULT_AFTER` in `common/config.h`.

> **Check this too:** the HC-SR04 driver only measures up to **200 cm**
> (`HC_SR04_DEFAULT_MAX_DISTANCE_CM`). With *nothing* in front of a sensor for 2 m,
> the simple `read_distance()` returns `-1` every time, which counts as bad readings.
> If you still see faults in an open room, test with a wall/box within 2 m.

---

## 5. Why there is no `hw.c` any more

`hw.c/h` existed only to switch between **simulation** and **real hardware**. With
simulation gone it was just a pointless extra layer, so it was removed:

* `motor/motor_controller.c` calls `drv8833` directly,
* `sensors/sensor_monitor.c` calls `hc_sr04` directly,
* `display/display_task.c` calls `oled_sh1106` directly.

The hardware is opened at start-up (`motor_controller_start()`, `sensor_monitor_start()`);
if that fails the program prints an error and exits instead of driving half-blind.

---

## 6. OLED screen

```
U1: 123.4 CM
U2: 118.0 CM

   EMERGENCY        <- big text: SAFE / WARNING / EMERGENCY / FAULT
```

A sensor that is not trusted shows `---`.

* **Driver** `src/drivers/oled_sh1106.c`: opens the I2C device (`/dev/i2c1`), sends the
  SH1106 start-up commands and writes pixels with `devctl(DCMD_I2C_SEND)`. It keeps
  the screen in a RAM framebuffer; `oled_print()` / `oled_print_big()` change only
  RAM and one `oled_flush()` sends the whole frame. Big text = the 5x7 font drawn 2x
  wider and 2x taller.
* **Task** `display/display_task.c`: lowest priority thread. Safety packs
  `{state, U1, U2}` into **one 32-bit pulse** (`MsgSendPulse`) so it never waits for
  the slow I2C bus; the task skips a redraw when nothing changed.
* If the picture is **upside down** set `OLED_ROTATE_180` to 1, if it is **shifted by
  2 pixels** change `OLED_COLUMN_OFFSET` (both in `src/drivers/oled_sh1106.h`).
* If no OLED is found the program still runs and logs `OLED not available`.

---

## 7. QNX concepts used (and where to find them)

| QNX / real-time concept | What it does here | File |
|---|---|---|
| **Channels** `ChannelCreate` | Each server task (Safety, Motor, Watchdog, Display) owns a channel | `safety_supervisor.c`, `motor_controller.c`, `watchdog.c`, `display_task.c` |
| **Connections** `ConnectAttach` | Clients attach to a server's channel | `navigation.c`, `sensor_monitor.c`, ... |
| **Synchronous message passing** `MsgSend / MsgReceive / MsgReply` | Commands and sensor data; `MsgSend` blocks until the reply, which gives a deterministic control loop | everywhere |
| **Pulses** `MsgSendPulse` | Non-blocking heartbeats to the watchdog; non-blocking status updates from Safety to the OLED task | `watchdog.c`, `safety_supervisor.c`, `display_task.c` |
| **Timers that send pulses** `timer_create` + `SIGEV_PULSE_INIT` | Drift-free periodic loops instead of `sleep()` | `system/ticker.c` |
| **Kernel timeouts** `TimerTimeout` | (a) receive timeout = motor dead-man timer, (b) send/reply timeout so nobody blocks forever on a stuck task | `motor_controller.c`, `rt_util.c` |
| **SCHED_FIFO fixed priorities** | Safety (30) > Motor (25) > Nav (20) > Watchdog (15) > Sensor (10) > Display (5) | `common/config.h`, `system/rt_util.c` |
| **Priority inheritance** | On the logger mutex (`PTHREAD_PRIO_INHERIT`) and implicitly on message passing | `common/log.c` |
| **Resource manager device + `devctl`** | I2C bus accessed as `/dev/i2c1` | `src/drivers/oled_sh1106.c` |
| **Message passing instead of shared memory** | Safety's state is only touched by Safety's thread -> no mutexes, no races | `safety_supervisor.c` |
| **Monotonic clock** `CLOCK_MONOTONIC` | Deadline measurement not affected by clock changes | `system/rt_util.c` |

---

## 8. Hardware (Raspberry Pi 4, BCM numbering)

| Part | Pins |
|---|---|
| Ultrasonic 0 (TRIG / ECHO) | GPIO 5 / GPIO 6 |
| Ultrasonic 1 (TRIG / ECHO) | GPIO 16 / GPIO 19 |
| DRV8833 EN (shared PWM speed) | GPIO 18 |
| DRV8833 right motor (AIN1 / AIN2) | GPIO 10 / GPIO 9 |
| DRV8833 left motor (BIN1 / BIN2) | GPIO 8 / GPIO 11 |
| OLED SH1106 (I2C1, address 0x3C) | SDA GPIO 2 / SCL GPIO 3 -> `/dev/i2c1` |

> **Important:** HC-SR04 ECHO outputs 5 V. Use a voltage divider (1 k / 2 k) before
> the Pi's GPIO, as described at the top of `src/drivers/hc_sr04.c`.

Pins can be changed in `src/common/config.h`.

---

## 9. Build and run

### In QNX Momentics (the normal way)

1. Copy the whole `src/` folder content into your project's `src/` (so that
   `src/qnx_mini_project.c`, `src/common/`, `src/system/`, ... exist). Delete any old
   `.c` files left from earlier versions - the IDE compiles **every** `.c` under `src/`,
   so two files with `main()` or old duplicates will break the build.
2. **Clean** the project (Project -> Clean, or delete the `build/` folder) so stale
   dependency files from older layouts are not used.
3. Link the GPIO library used by `drv8833.c`: Project Properties -> C/C++ Build ->
   Settings -> QCC Linker -> Libraries -> add `rpi_gpio` (same as your earlier project).
4. Build. **No include paths are needed:** every `#include` is written relative to the
   file that uses it (e.g. `#include "../common/config.h"`).

### Command line (optional)

```bash
source ~/qnx800/qnxsdp-env.sh
make -f Makefile.standalone        # builds ./qnx_mini_project
```

### Run on the Pi

Needs GPIO + real-time priority permission (e.g. root):

```bash
./qnx_mini_project
```

* Test with the wheels **off the ground** first. Press **Ctrl+C** to stop; the
  motors are stopped on exit.
* For a 32-bit target use `make -f Makefile.standalone ARCH=gcc_ntoarmle`.

### Watchdog / stale-data demo

```bash
./qnx_mini_project --test-hang
```

At 15 s the Sensor Monitor freezes for 3 s on purpose. Watch for:
`sensor data stale` (Safety fails safe) -> `SensorMonitor MISSED heartbeat`
(watchdog forces a stop) -> `SensorMonitor RECOVERED`.

---

## 10. Sample output

```
[      0 ms] === QNX Safety Supervisor (mini) starting ===
[     76 ms] [SAFETY] state=FAULT closest=-1.0cm requested=60% approved=0% reason: waiting for sensor data
[    301 ms] [SENSOR] sensor 1 ready
[    703 ms] [SENSOR] sensor 0 ready
[    755 ms] [SAFETY] state=SAFE closest=99.0cm requested=60% approved=60%
[   7187 ms] [SAFETY] state=WARNING closest=57.8cm requested=60% approved=57%
[   9077 ms] [SAFETY] state=EMERGENCY closest=14.1cm requested=60% approved=0%
[   9378 ms] [NAV] path blocked -> pivoting right
[  14944 ms] [SENSOR] sensor 1 FAULT (10 bad readings in a row)
[  17369 ms] [SENSOR] sensor 1 recovered
```

This run was produced on a PC with test doubles that fed **25 % dropouts and 5 % wild
spikes** into the same code: no false `FAULT` or `EMERGENCY` while the path was clear,
and a really unplugged sensor was still detected after ~1 s. Timing numbers on the real
QNX target will differ.

---

## 11. What we deliberately left out (compared to the advanced version)

IR line-follower array, encoders, IMU (MPU6050), cloud telemetry / network transport,
interactive CLI, and the multi-attempt sensor recovery manager. The four core ideas -
**priority override, deadline, sensor health, watchdog** - are all still there.

---

## 12. Tuning cheat-sheet (`src/common/config.h`)

| If you see... | Change... |
|---|---|
| Car stops too late | raise `WARNING_CM` / `EMERGENCY_CM` |
| Car creeps / motors hum | raise `MIN_MOVE_SPEED` |
| False `FAULT` from noisy sensors | raise `SENSOR_FAULT_AFTER` or `MEDIAN_WINDOW` |
| Reacts too slowly to obstacles | lower `MEDIAN_WINDOW` (3 is the minimum useful) |
| False watchdog alarms | raise `HEARTBEAT_TIMEOUT_MS` (but first look for a blocking call) |
| `DEADLINE MISSED` messages | something blocks Safety - check the motor / priorities |

---

## 13. Likely questions from judges

**Why message passing and not shared memory + mutexes?**
`MsgSend` is synchronous, so the sender is blocked until the server replies. State
is owned by exactly one thread, so there are no data races and the timing is predictable.

**How does Safety actually "override" Navigation?**
Two ways: (1) every command goes *through* Safety, which replies with the approved
speed, and (2) Safety has the highest SCHED_FIFO priority, so it pre-empts anything
else when it has work.

**What if Safety itself dies?**
Its heartbeat stops -> the watchdog logs it and forces a stop; also the Motor
Controller's dead-man timer stops the motors after 225 ms without any command.

**What if the Sensor Monitor hangs?**
The newest data becomes older than 400 ms -> Safety declares `FAULT` and stops.

**Why a median filter and not an average?**
An average is pulled by a spike (100,100,380,100,100 averages to 156 cm); the median
is 100. Ultrasonic sensors produce exactly this kind of occasional wild reading.

**Why does Safety use a pulse for the OLED instead of a message?**
`MsgSend` would block Safety until the display replies. The OLED is slow I2C and not
important, so a non-blocking pulse keeps the safety deadline independent of it.

**Why timer pulses instead of `sleep()`?**
A kernel periodic timer does not drift; `sleep()` adds the work time to every period.

**Why is the Sensor Monitor the lowest priority control task?**
Its HC-SR04 driver busy-waits for echoes. At a higher priority it starved Navigation
in the advanced version.

**What is `TimerTimeout` for?**
It makes the next blocking kernel call (receive / send / reply) give up after a time
limit, so no task can be blocked forever by another stuck task.

---

## 14. Possible extensions

* Plausibility check (reject jumps that are physically impossible)
* IR line-follower and lane-lost detection as another safety input
* Encoder RPM and IMU tilt checks
* Use `name_attach()` / `name_open()` instead of passing channel ids around
* Run each task as a separate process (better fault isolation, same messages)

---

*Note on testing:* the logic (messages, median filter, fault handling) and the OLED
driver's I2C byte stream were exercised on a PC with a small emulation of the QNX
message-passing API, `devctl` and an SH1106, plus test doubles for the HC-SR04 and
DRV8833 drivers. The build for the Pi uses the real QNX calls and drivers and must be
compiled and tested on your QNX setup, including the OLED orientation.
